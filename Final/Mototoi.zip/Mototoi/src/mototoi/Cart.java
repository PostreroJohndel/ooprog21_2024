package mototoi;

import java.awt.Color;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Cart extends javax.swing.JFrame {
    private DefaultTableModel tableModel;
    private static Cart instance;
    private String user, pass, mail;
    
    public Cart(String usr, String pass, String mail) {
        initComponents();
        this.username.setText(usr);
        this.pass = pass;
        this.mail = mail;
        jScrollPane4.getVerticalScrollBar().setUnitIncrement(16);
        tableModel = (DefaultTableModel) jTable1.getModel();
    }
    
    public static Cart getInstance(String usr, String pass, String mail) {
        if (instance == null) {
            instance = new Cart(usr, pass, mail);
        } else {
            // If the instance already exists, just update the user details
            instance.username.setText(usr);
            instance.pass = pass;
            instance.mail = mail;
        }
        return instance;
    }
    
    public void addToCart(String itemName, String price) {
        price = price.replaceAll("[^0-9]", "");
    
    // Convert the cleaned price string to an integer
    int priceInt = Integer.parseInt(price);
    
    // Add the item and price to the table
    tableModel.addRow(new Object[]{itemName, priceInt});
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane4 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        NavBar = new javax.swing.JPanel();
        home = new javax.swing.JLabel();
        Motorcycle = new javax.swing.JLabel();
        Parts = new javax.swing.JLabel();
        Cartlabel = new javax.swing.JLabel();
        UsernamePicture = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(800, 500));

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.setMinimumSize(new java.awt.Dimension(787, 1502));
        jPanel5.setPreferredSize(new java.awt.Dimension(731, 1553));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NavBar.setBackground(new java.awt.Color(51, 51, 51));
        NavBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/home1.png"))); // NOI18N
        home.setText("Home");
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });
        NavBar.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, -1, 40));

        Motorcycle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Motorcycle.setForeground(new java.awt.Color(255, 255, 255));
        Motorcycle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/brand1.png"))); // NOI18N
        Motorcycle.setText("Motorcycle");
        Motorcycle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MotorcycleMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                MotorcycleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                MotorcycleMouseExited(evt);
            }
        });
        NavBar.add(Motorcycle, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, -1, 40));

        Parts.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Parts.setForeground(new java.awt.Color(255, 255, 255));
        Parts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/marketplace1.png"))); // NOI18N
        Parts.setText("Parts");
        Parts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PartsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PartsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PartsMouseExited(evt);
            }
        });
        NavBar.add(Parts, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, -1, 40));

        Cartlabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Cartlabel.setForeground(new java.awt.Color(255, 255, 255));
        Cartlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/motor1.png"))); // NOI18N
        Cartlabel.setText("Cart");
        Cartlabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CartlabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CartlabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CartlabelMouseExited(evt);
            }
        });
        NavBar.add(Cartlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 0, -1, 40));

        UsernamePicture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/user1.png"))); // NOI18N
        NavBar.add(UsernamePicture, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 0, 35, 40));

        username.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        username.setText("Username");
        username.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernameMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernameMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernameMouseExited(evt);
            }
        });
        NavBar.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 0, 140, 40));

        jPanel5.add(NavBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 40));

        jToggleButton1.setText("Check Out");
        jToggleButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jToggleButton1MouseClicked(evt);
            }
        });
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });
        jPanel5.add(jToggleButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 390, -1, -1));

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Parts", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 650, 300));

        jButton1.setText("Remove");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, -1, -1));

        jScrollPane4.setViewportView(jPanel5);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jToggleButton1MouseClicked

    }//GEN-LAST:event_jToggleButton1MouseClicked

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        List<String> itemNames = new ArrayList<>();
        List<Integer> itemPrices = new ArrayList<>();
        int total = 0;

        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String itemName = (String) tableModel.getValueAt(i, 0);
            int itemPrice = (int) tableModel.getValueAt(i, 1);

            itemNames.add(itemName);
            itemPrices.add(itemPrice);

            total += itemPrice;
        }

        
        int option = JOptionPane.showConfirmDialog(this,
                "Total: ₱" + total + "\nDo you want to proceed to checkout?",
                "Checkout Confirmation",
                JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            new Checkout(total).setVisible(true);
        }
        tableModel.setRowCount(0);
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        new Home(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        home.setForeground(Color.RED);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        home.setForeground(Color.white);
    }//GEN-LAST:event_homeMouseExited

    private void MotorcycleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MotorcycleMouseClicked
        new Motorcycle(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MotorcycleMouseClicked

    private void MotorcycleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MotorcycleMouseEntered
        Motorcycle.setForeground(Color.RED);
    }//GEN-LAST:event_MotorcycleMouseEntered

    private void MotorcycleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MotorcycleMouseExited
        Motorcycle.setForeground(Color.white);
    }//GEN-LAST:event_MotorcycleMouseExited

    private void PartsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PartsMouseClicked
        new Parts(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PartsMouseClicked

    private void PartsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PartsMouseEntered
        Parts.setForeground(Color.RED);
    }//GEN-LAST:event_PartsMouseEntered

    private void PartsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PartsMouseExited
        Parts.setForeground(Color.white);
    }//GEN-LAST:event_PartsMouseExited

    private void CartlabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartlabelMouseClicked
        
    }//GEN-LAST:event_CartlabelMouseClicked

    private void CartlabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartlabelMouseEntered
        Cartlabel.setForeground(Color.RED);
    }//GEN-LAST:event_CartlabelMouseEntered

    private void CartlabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartlabelMouseExited
        Cartlabel.setForeground(Color.white);
    }//GEN-LAST:event_CartlabelMouseExited

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int selectedRow = jTable1.getSelectedRow();  // Get the selected row index
    if (selectedRow != -1) {  // If a row is selected
        tableModel.removeRow(selectedRow);  // Remove the selected row from the table
    } else {
        // Optionally, you can show a message if no row is selected
        JOptionPane.showMessageDialog(this, "Please select a row to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void usernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseClicked
        new UserSpace(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_usernameMouseClicked

    private void usernameMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseEntered
        username.setForeground(Color.RED);
    }//GEN-LAST:event_usernameMouseEntered

    private void usernameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseExited
        username.setForeground(Color.white);
    }//GEN-LAST:event_usernameMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cart("","","").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Cartlabel;
    private javax.swing.JLabel Motorcycle;
    private javax.swing.JPanel NavBar;
    private javax.swing.JLabel Parts;
    private javax.swing.JLabel UsernamePicture;
    private javax.swing.JLabel home;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
