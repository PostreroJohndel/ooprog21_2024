package mototoi;

import java.awt.Color;


public class Motorcycle extends javax.swing.JFrame {

    private Cart cartFrame = Cart.getInstance("","","");
    private String pass, mail;
    
    public Motorcycle(String usr, String pass, String mail) {
        initComponents();
        this.username.setText(usr);
        this.pass = pass;
        this.mail = mail;
        jScrollPane2.getVerticalScrollBar().setUnitIncrement(16);
    }
    
    private void moreDetails(String image, String name, String def, String 
            maintenance, String issues, String partimage1, String partimage2,
            String partname1, String partname2, String price1, String price2) {
        MotorFrame motorFrame = new MotorFrame(image, name, def, maintenance, issues, partimage1, partimage2, partname1, partname2, price1, price2);
        motorFrame.setVisible(true);
        motorFrame.setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        NavBar2 = new javax.swing.JPanel();
        home1 = new javax.swing.JLabel();
        Motorcycle1 = new javax.swing.JLabel();
        Parts1 = new javax.swing.JLabel();
        Cart1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        Motor1 = new javax.swing.JPanel();
        Pic1 = new javax.swing.JLabel();
        Back1 = new javax.swing.JLabel();
        Motor2 = new javax.swing.JPanel();
        Pic2 = new javax.swing.JLabel();
        Back2 = new javax.swing.JLabel();
        Motor3 = new javax.swing.JPanel();
        Pic3 = new javax.swing.JLabel();
        Back3 = new javax.swing.JLabel();
        Motor4 = new javax.swing.JPanel();
        Pic4 = new javax.swing.JLabel();
        Back4 = new javax.swing.JLabel();
        Motor5 = new javax.swing.JPanel();
        Pic5 = new javax.swing.JLabel();
        Back5 = new javax.swing.JLabel();
        Motor6 = new javax.swing.JPanel();
        Pic6 = new javax.swing.JLabel();
        Back6 = new javax.swing.JLabel();
        Motor7 = new javax.swing.JPanel();
        Pic7 = new javax.swing.JLabel();
        Back7 = new javax.swing.JLabel();
        Motor8 = new javax.swing.JPanel();
        Pic8 = new javax.swing.JLabel();
        Back8 = new javax.swing.JLabel();
        Motor9 = new javax.swing.JPanel();
        Pic9 = new javax.swing.JLabel();
        Back9 = new javax.swing.JLabel();
        Motor10 = new javax.swing.JPanel();
        Pic10 = new javax.swing.JLabel();
        Back10 = new javax.swing.JLabel();
        Motor11 = new javax.swing.JPanel();
        Pic11 = new javax.swing.JLabel();
        Back11 = new javax.swing.JLabel();
        Motor12 = new javax.swing.JPanel();
        Pic12 = new javax.swing.JLabel();
        Back12 = new javax.swing.JLabel();
        Motor13 = new javax.swing.JPanel();
        Pic13 = new javax.swing.JLabel();
        Back13 = new javax.swing.JLabel();
        Motor14 = new javax.swing.JPanel();
        Pic14 = new javax.swing.JLabel();
        Back14 = new javax.swing.JLabel();
        Motor15 = new javax.swing.JPanel();
        Pic15 = new javax.swing.JLabel();
        Back15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane2.setMinimumSize(new java.awt.Dimension(800, 500));
        jScrollPane2.setPreferredSize(new java.awt.Dimension(800, 500));
        jScrollPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane2MouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(102, 102, 102));
        jPanel3.setMinimumSize(new java.awt.Dimension(798, 1700));
        jPanel3.setPreferredSize(new java.awt.Dimension(798, 1670));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NavBar2.setBackground(new java.awt.Color(51, 51, 51));
        NavBar2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        home1.setForeground(new java.awt.Color(255, 255, 255));
        home1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/home1.png"))); // NOI18N
        home1.setText("Home");
        home1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                home1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                home1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                home1MouseExited(evt);
            }
        });
        NavBar2.add(home1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, -1, 40));

        Motorcycle1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Motorcycle1.setForeground(new java.awt.Color(255, 255, 255));
        Motorcycle1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/brand1.png"))); // NOI18N
        Motorcycle1.setText("Motorcycle");
        Motorcycle1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Motorcycle1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Motorcycle1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Motorcycle1MouseExited(evt);
            }
        });
        NavBar2.add(Motorcycle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, -1, 40));

        Parts1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Parts1.setForeground(new java.awt.Color(255, 255, 255));
        Parts1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/marketplace1.png"))); // NOI18N
        Parts1.setText("Parts");
        Parts1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Parts1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Parts1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Parts1MouseExited(evt);
            }
        });
        NavBar2.add(Parts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, -1, 40));

        Cart1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Cart1.setForeground(new java.awt.Color(255, 255, 255));
        Cart1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/motor1.png"))); // NOI18N
        Cart1.setText("Cart");
        Cart1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Cart1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Cart1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Cart1MouseExited(evt);
            }
        });
        NavBar2.add(Cart1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 0, -1, 40));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/user1.png"))); // NOI18N
        NavBar2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 0, 35, 40));

        username.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        username.setText("Username");
        username.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernameMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usernameMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                usernameMouseExited(evt);
            }
        });
        NavBar2.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 0, 140, 40));

        jPanel3.add(NavBar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 40));

        Motor1.setBackground(new java.awt.Color(0, 0, 0));
        Motor1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Motor1MouseClicked(evt);
            }
        });
        Motor1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto1.png"))); // NOI18N
        Pic1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic1MouseExited(evt);
            }
        });
        Motor1.add(Pic1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 210));

        Back1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Back1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Back1MouseClicked(evt);
            }
        });
        Motor1.add(Back1, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 200, 220));

        Motor2.setBackground(new java.awt.Color(0, 0, 0));
        Motor2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Motor2MouseClicked(evt);
            }
        });
        Motor2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic2.setBackground(new java.awt.Color(0, 0, 0));
        Pic2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto2.png"))); // NOI18N
        Pic2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic2MouseExited(evt);
            }
        });
        Motor2.add(Pic2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor2.add(Back2, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, -1, 220));

        Motor3.setBackground(new java.awt.Color(0, 0, 0));
        Motor3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Motor3MouseClicked(evt);
            }
        });
        Motor3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto3.png"))); // NOI18N
        Pic3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic3MouseExited(evt);
            }
        });
        Motor3.add(Pic3, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, 190, 220));

        Back3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor3.add(Back3, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 70, 200, -1));

        Motor4.setBackground(new java.awt.Color(0, 0, 0));
        Motor4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto4.png"))); // NOI18N
        Pic4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic4MouseExited(evt);
            }
        });
        Motor4.add(Pic4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor4.add(Back4, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, -1, -1));

        Motor5.setBackground(new java.awt.Color(0, 0, 0));
        Motor5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto5.png"))); // NOI18N
        Pic5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic5MouseExited(evt);
            }
        });
        Motor5.add(Pic5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor5.add(Back5, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 400, -1, 220));

        Motor6.setBackground(new java.awt.Color(0, 0, 0));
        Motor6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto6.png"))); // NOI18N
        Pic6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic6MouseExited(evt);
            }
        });
        Motor6.add(Pic6, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, 200, 220));

        Back6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor6.add(Back6, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 400, -1, -1));

        Motor7.setBackground(new java.awt.Color(0, 0, 0));
        Motor7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto7.png"))); // NOI18N
        Pic7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic7MouseExited(evt);
            }
        });
        Motor7.add(Pic7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor7.add(Back7, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 740, -1, -1));

        Motor8.setBackground(new java.awt.Color(0, 0, 0));
        Motor8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto8.png"))); // NOI18N
        Pic8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic8MouseExited(evt);
            }
        });
        Motor8.add(Pic8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor8.add(Back8, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor8, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 740, -1, 220));

        Motor9.setBackground(new java.awt.Color(0, 0, 0));
        Motor9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto9.png"))); // NOI18N
        Pic9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic9MouseExited(evt);
            }
        });
        Motor9.add(Pic9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor9.add(Back9, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 740, -1, -1));

        Motor10.setBackground(new java.awt.Color(0, 0, 0));
        Motor10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto91.png"))); // NOI18N
        Pic10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic10MouseExited(evt);
            }
        });
        Motor10.add(Pic10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor10.add(Back10, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1080, -1, -1));

        Motor11.setBackground(new java.awt.Color(0, 0, 0));
        Motor11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto92.png"))); // NOI18N
        Pic11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic11MouseExited(evt);
            }
        });
        Motor11.add(Pic11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor11.add(Back11, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 1080, -1, 220));

        Motor12.setBackground(new java.awt.Color(0, 0, 0));
        Motor12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto93.png"))); // NOI18N
        Pic12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic12MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic12MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic12MouseExited(evt);
            }
        });
        Motor12.add(Pic12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor12.add(Back12, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor12, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 1080, -1, -1));

        Motor13.setBackground(new java.awt.Color(0, 0, 0));
        Motor13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto94.png"))); // NOI18N
        Pic13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic13MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic13MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic13MouseExited(evt);
            }
        });
        Motor13.add(Pic13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor13.add(Back13, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1420, -1, -1));

        Motor14.setBackground(new java.awt.Color(0, 0, 0));
        Motor14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto95.png"))); // NOI18N
        Pic14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic14MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic14MouseExited(evt);
            }
        });
        Motor14.add(Pic14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor14.add(Back14, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor14, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 1420, -1, 220));

        Motor15.setBackground(new java.awt.Color(0, 0, 0));
        Motor15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pic15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/moto96.png"))); // NOI18N
        Pic15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pic15MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Pic15MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Pic15MouseExited(evt);
            }
        });
        Motor15.add(Pic15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 220));

        Back15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/back.png"))); // NOI18N
        Motor15.add(Back15, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 190, 210));

        jPanel3.add(Motor15, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 1420, -1, -1));

        jScrollPane2.setViewportView(jPanel3);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Pic1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic1MouseClicked
        moreDetails(
                "/pictures/moto1.png",
                "Harley Davidson Street 500",
                "A compact cruiser designed for entry-level riders, offering Harley-Davidson’s signature style with an approachable engine size and agile handling. Ideal for city commuting and casual cruising, the Street 500 combines modern features with classic Harley flair.",
                "<b>Oil Change:</b> Every 5,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 10,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 10,000 km\n"
                + "<b>Brake Fluid Change:</b> Every 2 years\n"
                + "<b>Coolant Change:</b> Every 2 years",
                "<b>1.) Battery Drain:</b>\n" +
                "<b>Cause:</b> Extended use of electrical accessories or an aging battery.\n" +
                "<b>Solution:</b> Avoid overloading the electrical system. Regularly charge the battery and replace if it's weak or underperforming.\n\n" +
                "<b>2.) Clutch Issues:</b>\n" +
                "<b>Cause:</b> Frequent heavy clutch use or improper adjustment.\n" +
                "<b>Solution:</b> Adjust the clutch lever for proper engagement and replace the clutch cable if it becomes frayed or difficult to pull.\n\n" +
                "<b>3.) Chain and Sprocket Wear:</b>\n" +
                "<b>Cause:</b> Extended city riding or aggressive acceleration causing chain wear.\n" +
                "<b>Solution:</b> Lubricate the chain every 500-1,000 km, adjust tension, and replace the chain and sprockets as needed.", 
                "/pictures/HarleyBrake.png",
                "/pictures/HarleyCoolant.png", 
                "<b>Harley Genuine or EBC Brake Pads</b>",
                "<b>Harley Genuine Coolant or equivalent</b>",
                "₱438",
                "₱2060");
    }//GEN-LAST:event_Pic1MouseClicked

    private void Pic1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic1MouseEntered
        Motor1.setBackground(Color.white);
    }//GEN-LAST:event_Pic1MouseEntered

    private void Pic1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic1MouseExited
        Motor1.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic1MouseExited

    private void Back1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Back1MouseClicked

    }//GEN-LAST:event_Back1MouseClicked

    private void Motor1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motor1MouseClicked

    }//GEN-LAST:event_Motor1MouseClicked

    private void Pic2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic2MouseClicked
        moreDetails(
                "/pictures/moto2.png",
                "Suzuki Raider R150 Fi",
                "A fuel-injected underbone motorcycle with a sleek design and powerful performance, ideal for speed enthusiasts and urban riders.",
                "<b>Oil Change:<b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 8,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 12,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000–8,000 km", 
                "<b>1.) Clutch Slippage:</b>\n" 
                + "<b>Cause:</b> Aggressive riding or worn clutch plates.\n"
                + "<b>Solution:<b> Adjust the clutch lever free play regularly. Replace clutch plates when slippage occurs.\n"
                + "<b>2.) Overheating:</b>\n"
                + "<b>Cause:</b> Insufficient coolant or clogged radiator.\n"
                + "<b>Solution:</b> Check and top up coolant regularly. Clean the radiator to ensure proper cooling.\n"
                + "<b>3.) Chain Noise:</b>\n"
                + "<b>Cause:</b> Dry or loose chain.\n"
                + "<b>Solution:</b> Lubricate the chain every 500–1,000 km and adjust the tension to the recommended setting.", 
                "/pictures/part21.png",
                "/pictures/part22.png", 
                "<b>NGK CR8E or equivalent</b>",
                "<b>Suzuki Genuine 10W-40 Oil</b>",
                "₱295",
                "P550");
    }//GEN-LAST:event_Pic2MouseClicked

    private void Pic2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic2MouseEntered
        Motor2.setBackground(Color.WHITE);
    }//GEN-LAST:event_Pic2MouseEntered

    private void Pic2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic2MouseExited
        Motor2.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic2MouseExited

    private void Motor2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motor2MouseClicked

    }//GEN-LAST:event_Motor2MouseClicked

    private void Pic3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic3MouseClicked
        moreDetails(
                "/pictures/moto3.png",
                "Yamaha NMAX 155",
                "A sleek, high-performance scooter designed for both city commuting and long-distance rides, featuring modern technology and a stylish design.",
                " <b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:/<b> Every 8,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 8,000 km\n"
                + "<b>Drive Belt Inspection:</b> Every 12,000 km",
                "1.) <b>Brake Pad Wear:</b>\n"
                + "<b>Cause:</b> Frequent city commuting or hard braking.\n"
                + "<b>Solution:</b> Inspect the brake pads every 6,000–8,000 km. Replace with Yamaha Genuine or performance aftermarket pads if worn.\n"
                + "2.)<b>Battery Drain:</b>\n"
                + "<b>Cause:</b> Extended use of electrical accessories or malfunctioning electrical systems.\n"
                + "<b>Solution:</b> Turn off accessories when not in use and regularly check battery voltage. Replace the battery if charging issues occur.\n"
                + "3.) <b>Tire Wear:</b>\n"
                + "<b>Cause:</b> Improper tire pressure or frequent riding on rough surfaces.\n"
                + "<b>Solution:</b> Maintain proper tire pressure and inspect tires regularly for wear. Replace tires when the tread depth is low.", 
                "/pictures/part31.png",
                "/pictures/part32.png", 
                "<b>Yamaha Genuine Yamalube 10W-40</b>",
                "<b>Yamaha Genuine V-Belt</b>",
                "₱350",
                "₱500");
    }//GEN-LAST:event_Pic3MouseClicked

    private void Pic3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic3MouseEntered
        Motor3.setBackground(Color.WHITE);
    }//GEN-LAST:event_Pic3MouseEntered

    private void Pic3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic3MouseExited
        Motor3.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic3MouseExited

    private void Motor3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motor3MouseClicked

    }//GEN-LAST:event_Motor3MouseClicked

    private void Pic4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic4MouseClicked
        moreDetails(
                "/pictures/moto4.png",
                "KTM Duke 390",
                "A lightweight, high-performance naked bike with a bold design, cutting-edge technology, and agile handling, perfect for urban and spirited rides.",
                "<b>Maintenance instructionsOil Change:</b> Every 5,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 10,000 km\n"
                + "<b>Chain Lubrication:</b> Every 500–1,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000 km",
                "<b>1.) Overheating:</b>\n"
                + "<b>ause:</b> Compact high-performance engine generates heat in traffic or hot weather.\n"
                + "<b>Solution:</b> Regularly check coolant levels and ensure proper airflow to the radiator. Use high-performance coolant.\n"
                + "<b>2.) Chain Wear and Noise:</b>\n"
                + "<b>Cause:</b> Aggressive riding can strain the chain.\n"
                + "<b>Solution:</b> Clean and lubricate the chain regularly and adjust tension as needed. Replace worn chains promptly.\n"
                + "<b>3.) Electrical Issues:</b>\n"
                + "<b>Cause:</b> Sensitive electronics may face issues with poor battery maintenance or exposure to elements.\n"
                + "<b>Solution:</b> Keep battery terminals clean and secure. Use a cover to protect the bike during storage.", 
                "/pictures/part41.png",
                "/pictures/part42.png",
                "<b>Motorex Power Synt 10W-50</b>",
                "<b>KTM Genuine or Brembo Performance Pads</b>",
                "₱1,188",
                "₱3,110");
    }//GEN-LAST:event_Pic4MouseClicked

    private void Pic4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic4MouseEntered
        Motor4.setBackground(Color.white);
    }//GEN-LAST:event_Pic4MouseEntered

    private void Pic4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic4MouseExited
        Motor4.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic4MouseExited

    private void Pic5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic5MouseClicked
        moreDetails(
                "/pictures/moto5.png",
                "Suzuki Gixxer 150",
                "A stylish and performance-oriented naked bike, ideal for city commuting and light touring. It combines agility, fuel efficiency, and modern features for daily riding.",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "Air Filter Cleaning/Replacement:</b> Every 8,000 km\n"
                + "<b>Chain Lubrication:</b> Every 500–1,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000–8,000 km",
                "<b>1.) Chain Wear:</b>\n"
                + "<b>Cause:</b> Frequent riding in city traffic leads to chain stretch.\n"
                + "<b>Solution:</b> Clean and lubricate the chain regularly and adjust tension as needed. Replace the chain if it shows significant wear.\n"
                + "<b>2.) Overheating:</b>\n"
                + "<b>Cause:</b> Prolonged idling or high ambient temperatures.\n"
                + "<b>Solution:</b> Ensure proper airflow by not idling for extended periods and checking coolant levels regularly.\n"
                + "<b>3.) Electrical Glitches:</b>\n"
                + "<b>Cause:</b> Poor connections in the wiring or battery issues.\n"
                + "<b>Solution:</b> Inspect and clean battery terminals. Replace the battery if charging issues persist.", 
                "/pictures/part51.png",
                "/pictures/part52.png",
                "<b>NGK CR8E or equivalent</b>",
                "<b>Suzuki Genuine Air Filter Element</b>",
                "₱295",
                "₱524");
    }//GEN-LAST:event_Pic5MouseClicked

    private void Pic5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic5MouseEntered
        Motor5.setBackground(Color.white);
    }//GEN-LAST:event_Pic5MouseEntered

    private void Pic5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic5MouseExited
        Motor5.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic5MouseExited

    private void Pic6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic6MouseClicked
        moreDetails(
                "/pictures/moto6.png",
                "Kawasaki Ninja ZX-4RR",
                "A high-performance sportbike featuring a 399cc four-cylinder engine, aggressive styling, and advanced electronics, designed for track and spirited road riding.",
                "<b>Oil Change:</b> Every 4,000–6,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 12,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 8,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000–8,000 km",
                "<b>1.) High Engine Heat:</b>\n"
                + "<b>Cause:</b> The compact four-cylinder engine generates significant heat, especially in traffic.\n"
                + "<b>Solution:</b> Regularly monitor and top up coolant levels. Use high-performance, heat-resistant engine oil.\n"
                + "<b>2.) Chain Wear:</b>\n"
                + "<b>Cause:</b> High power output can strain the chain.\n"
                + "<b>Solution:</b> Clean and lubricate the chain every 500–1,000 km. Check for tension and adjust as needed.\n"
                + "<b>3.) Brake Fade:</b>\n"
                + "<b>Cause:</b> Extended high-speed riding or aggressive braking.\n"
                + "<b>Solution:</b> Use high-quality brake fluid and replace it every 1–2 years. Upgrade to performance brake pads if needed.", 
                "/pictures/part61.png",
                "/pictures/part62.png", 
                "<b>Kawasaki Genuine 10W-40 Synthetic Oil<b>",
                "<b>Kawasaki Super Coolant or equivalent<b>",
                "₱298",
                "₱175");
    }//GEN-LAST:event_Pic6MouseClicked

    private void Pic6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic6MouseEntered
        Motor6.setBackground(Color.white);
    }//GEN-LAST:event_Pic6MouseEntered

    private void Pic6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic6MouseExited
        Motor6.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic6MouseExited

    private void Pic7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic7MouseClicked
        moreDetails(
                "/pictures/moto7.png",
                "Honda Click 125i",
                "A sleek, fuel-efficient scooter perfect for Cebu’s city rides, featuring modern design, LED lighting, a fully digital meter panel, and an Idling Stop System (ISS).",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 8,000 km\n"
                + "<b>Air Filter Cleaning:</b> Every 8,000 km\n"
                + "<b>Drive Belt Check:</b> Every 12,000 km",
                "<b>1.) Battery Drain:</b> Caused by frequent use of ISS or extra accessories.\n"
                + "<b>2.) Coolant Leaks:</b> Due to worn hoses or low levels.\n"
                + "<b>3.) Fuel Injector Clogging:</b> From poor-quality fuel.\n"
                + "<b>4.) Tire Problems:</b> Improper pressure causing uneven wear.", 
                "/pictures/part71.png",
                "/pictures/part72.png", 
                "<b>Honda Genuine Oil 10W-30 MA</b>",
                "<b>NGK CPR7EA-9</b>",
                "₱270",
                "₱218");
    }//GEN-LAST:event_Pic7MouseClicked

    private void Pic7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic7MouseEntered
        Motor7.setBackground(Color.white);
    }//GEN-LAST:event_Pic7MouseEntered

    private void Pic7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic7MouseExited
        Motor7.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic7MouseExited

    private void Pic8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic8MouseClicked
        moreDetails(
                "/pictures/moto8.png",
                "Honda CRF150L",
                "A versatile dual-sport motorcycle designed for both on-road and off-road riding. Features robust suspension, a durable frame, and fuel-efficient performance.",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Chain Adjustment:</b> Every 1,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 8,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000 km",
                "<b>1.) Chain Wear:</b>\n"
                + "<b>Cause:</b> Frequent off-road use leads to faster wear.\n"
                + "<b>Solution:</b> Regularly clean and lubricate the chain with a high-quality chain lube every 500–1,000 km. Replace the chain when signs of excessive wear appear.\n"
                + "<b>2.) Suspension Seal Issues:</b>\n"
                + "<b>Cause:</b> Dust and debris may damage fork seals.\n"
                + "<b>Solution:</b> Clean the suspension forks after every ride, especially off-road. Use fork seal protectors to reduce debris entry. Replace seals if leaks occur.\n"
                + "<b>3.) Tire Tread Wear:</b>\n"
                + "<b>Cause:</b> Riding on rugged terrain accelerates tread wear.\n"
                + "<b>Solution:</b> Monitor tire condition regularly and maintain proper air pressure. Replace tires with off-road-ready models when tread depth is low.", 
                "/pictures/part81.png",
                "/pictures/part82.png",
                "<b>Honda Genuine Oil 10W-40</b>",
                "<b>Honda Genuine Air Filter Element</b>",
                "₱240",
                "₱351");
    }//GEN-LAST:event_Pic8MouseClicked

    private void Pic8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic8MouseEntered
        Motor8.setBackground(Color.white);
    }//GEN-LAST:event_Pic8MouseEntered

    private void Pic8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic8MouseExited
        Motor8.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic8MouseExited

    private void Pic9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic9MouseClicked
        moreDetails(
                "/pictures/moto9.png",
                "Kawasaki Ninja 400",
                "The Kawasaki Ninja 400 is a sportbike that offers a blend of performance and agility, making it suitable for both novice and experienced riders.",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 8,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 12,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000–8,000 km",
                "<b>1.) Clutch Slippage:</b> Caused by aggressive riding or worn clutch plates. Solution: Regularly adjust the clutch lever free play and replace clutch plates when slippage occurs.\n"
                + "<b>2.) Overheating:</b> Caused by insufficient coolant or clogged radiator. Solution: Check and top up coolant regularly, and clean the radiator to ensure proper cooling.\n"
                + "<b>3.) Chain Noise:</b> Caused by a dry or loose chain. Solution: Lubricate the chain every 500–1,000 km and adjust the tension to the recommended setting.", 
                "/pictures/part91.png",
                "/pictures/part92.png", 
                "<b>Kawasaki Super Coolant</b>",
                "<b>Kawasaki Genuine Air Filter</b>",
                "₱1620",
                "₱795");
    }//GEN-LAST:event_Pic9MouseClicked

    private void Pic9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic9MouseEntered
        Motor9.setBackground(Color.white);
    }//GEN-LAST:event_Pic9MouseEntered

    private void Pic9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic9MouseExited
        Motor9.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic9MouseExited

    private void Pic10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic10MouseClicked
        moreDetails(
                "/pictures/moto91.png",
                "KTM RC 390",
                "A lightweight and aggressive sportbike designed for track enthusiasts and daily riders. The KTM RC 390 combines cutting-edge technology, sharp handling, and a strong engine in a stylish, compact package.",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 8,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 10,000 km\n"
                + "<b>Brake Fluid Change:</b> Every 2 years\n"
                + "<b>Coolant Change:</b> Every 2 years or 20,000 km",
                "<b>1.) Chain Wear and Noise:</b>\n"
                + "<b>Cause:</b> Aggressive riding or improper maintenance.\n"
                + "<b>Solution:</b> Clean and lubricate the chain every 500–1,000 km. Adjust chain tension and replace when it shows signs of excessive wear.\n"
                + "<b>2.) Overheating:</b>\n"
                + "<b>Cause:</b> High-performance engine may generate excess heat during extended rides or in hot climates.\n"
                + "<b>Solution:</b> Keep the coolant topped up and ensure the radiator is clean. Avoid prolonged idling and high-speed riding in traffic.\n"
                + "<b>3.) Brake Fade:</b>\n"
                + "<b>Cause:</b> High-speed riding or track use can cause the brake fluid to overheat.\n"
                + "<b>Solution:</b> Change brake fluid every 1–2 years and use high-performance brake pads for track use.", 
                "/pictures/part93.png",
                "/pictures/part94.png",
                "<b>Pirelli Diablo Rosso III</b>",
                "<b>Motorex Chain Lube</b>",
                "₱9,099",
                "₱630");
    }//GEN-LAST:event_Pic10MouseClicked

    private void Pic10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic10MouseEntered
        Motor10.setBackground(Color.white);
    }//GEN-LAST:event_Pic10MouseEntered

    private void Pic10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic10MouseExited
        Motor10.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic10MouseExited

    private void Pic11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic11MouseClicked
        moreDetails(
                "/pictures/moto92.png",
                "Ducati Monster 1200",
                "A high-performance naked bike designed for aggressive riding with a striking design and top-tier power, combining Ducati’s iconic styling with modern technology and dynamic performance.",
                "<b>Oil Change:</b> Every 7,500 km\n"
                + "<b>Spark Plug Replacement:</b> Every 12,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 12,000 km\n"
                + "<b>rake Fluid Change:</b> Every 2 years\n"
                + "<b>Coolant Change:</b> Every 2 years",
                "<b>1.) Clutch Slippage:</b>\n"
                + "<b>Cause:</b> Aggressive riding or worn-out clutch plates.\n"
                + "<b>Solution:</b> Check clutch fluid levels regularly. Replace the clutch plates when they show signs of slippage or wear.\n"
                + "<b>2.) Chain Wear:</b>\n"
                + "<b>Cause:</b> High power output causes increased strain on the chain.\n"
                + "<b>Solution:</b> Clean and lubricate the chain every 500–1,000 km. Adjust chain tension and replace if excessively worn.\n"
                + "<b>3.) Overheating:</b>\n"
                + "<b>Cause:</b> Prolonged high-speed riding or insufficient cooling due to low coolant levels.\n"
                + "<b>Solution:</b> Monitor and top up coolant regularly. Clean the radiator and ensure proper airflow. Avoid extended idling in traffic.", 
                "/pictures/part95.png",
                "/pictures/part96.png",
                "<b>Brembo High-Performance Brake Pads</b>",
                "<b>NGK CR9E</b>",
                "₱2640",
                "₱295");
    }//GEN-LAST:event_Pic11MouseClicked

    private void Pic11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic11MouseEntered
        Motor11.setBackground(Color.white);
    }//GEN-LAST:event_Pic11MouseEntered

    private void Pic11MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic11MouseExited
        Motor11.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic11MouseExited

    private void Pic12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic12MouseClicked
        moreDetails(
                "/pictures/moto93.png",
                "Yamaha YZF-R15",
                "A sporty and aggressive-looking entry-level supersport motorcycle designed for both beginners and experienced riders who enjoy precision handling and high-performance capabilities.",
                "<b>Oil Change:</b> Every 4,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 8,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 8,000 km\n"
                + "<b>Brake Pad Inspection:</b> Every 6,000–8,000 km",
                "<b>1.) Chain Wear and Noise:</b>\n"
                + "<b>Cause:</b> Frequent riding or aggressive acceleration.\n"
                + "<b>Solution:</b> Clean and lubricate the chain every 500–1,000 km and adjust the tension as needed. Replace the chain if significant wear is noticed.\n"
                + "<b>2.) Overheating:</b>\n"
                + "<b>Cause:</b> Continuous high-speed riding, especially in hot conditions.\n"
                + "<b>Solution:</b> Ensure coolant levels are maintained, and avoid prolonged high-speed rides in traffic. Clean the radiator fins regularly.\n"
                + "<b>3.) Battery Drain:</b>\n"
                + "<b>Cause:</b> Electrical systems and accessories drawing excess power.\n"
                + "<b>Solution:</b> Avoid leaving accessories on when the engine is off. Replace the battery if there are consistent charging issues.", 
                "/pictures/part97.png",
                "/pictures/part98.png",
                "<b>Yamalube 10W-40</b>",
                "<b>NGK CR9E</b>",
                "₱335",
                "₱295");
    }//GEN-LAST:event_Pic12MouseClicked

    private void Pic12MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic12MouseEntered
        Motor12.setBackground(Color.white);
    }//GEN-LAST:event_Pic12MouseEntered

    private void Pic12MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic12MouseExited
        Motor12.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic12MouseExited

    private void Pic13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic13MouseClicked
        moreDetails(
                "/pictures/moto94.png",
                "Royal Enfield Himalayan 450",
                "An adventure touring motorcycle designed for rugged terrains and long-distance rides, featuring modern engineering with a robust frame and capable off-road features.",
                "<b>Oil Change:</b> Every 5,000 km\n"
                + "<b>Air Filter Replacement:</b> Every 10,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 12,000 km\n"
                + "vChain Lubrication:</b> Every 500–1,000 km",
                "<b>1.) Overheating on Slow Trails:</b>\n"
                + "<b>Cause:</b> Continuous low-speed riding in rough terrain.\n"
                + "<b>Solution:</b> Ensure proper coolant levels and clean radiator fins regularly. Avoid excessive idling.\n"
                + "<b>2.)Chain Noise and Wear:</b>\n"
                + "<b>Cause:</b> Dirt and debris from off-road use.\n"
                + "<b>Solution:</b> Clean and lubricate the chain after off-road rides. Adjust tension as needed to prevent uneven wear.\n"
                + "<b>3.) Brake Pad Wear:</b>\n"
                + "<b>Cause:</b> Frequent braking on rugged terrain.\n"
                + "<b>Solution:</b> Inspect brake pads regularly and replace them with Royal Enfield Genuine or high-performance alternatives when worn.", 
                "/pictures/part99.png",
                "/pictures/part991.png",
                "<b>Motul 7100 10W-50</b>",
                "<b>NGK Iridium IX or equivalent</b>",
                "₱909",
                "₱ 289");
    }//GEN-LAST:event_Pic13MouseClicked

    private void Pic13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic13MouseEntered
        Motor13.setBackground(Color.white);
    }//GEN-LAST:event_Pic13MouseEntered

    private void Pic13MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic13MouseExited
        Motor13.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic13MouseExited

    private void Pic14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic14MouseClicked
        moreDetails(
                "/pictures/moto95.png",
                "Honda TMX 125 Alpha",
                "A durable and fuel-efficient motorcycle designed for daily commuting and heavy-duty use, ideal for businesses and urban riders.",
                "<b>Oil Change:</b> Every 3,000 km\n"
                + "<b>Chain Adjustment & Lubrication:</b> Every 1,000 km\n"
                + "<b>Valve Clearance Check:</b> Every 6,000 km\n"
                + "<b>Spark Plug Replacement:</b> Every 10,000 km",
                "<b>1.) Low Power Output:</b>\n"
                + "<b>Cause:</b> Clogged air filter or old spark plug.\n"
                + "<b>Solution:</b> Replace air filter and spark plug during maintenance.\n"
                + "<b>2.) Overheating:</b>\n"
                + "<b>Cause:</b> Lack of proper oil levels or prolonged idling.\n"
                + "<b>Solution:</b> Regularly check oil level and avoid idling for extended periods.\n"
                + "<b>3.) Hard Starting:</b>\n"
                + "<b>Cause:</b> Weak battery or fuel delivery issues.\n"
                + "<b>Solution:</b> Check battery health and clean the carburetor.", 
                "/pictures/part992.png",
                "/pictures/part993.png",
                "<b>Motul 4T</b>",
                "<b>OEM Air Filter for Honda TMX 125</b>",
                "₱389",
                "₱490");
    }//GEN-LAST:event_Pic14MouseClicked

    private void Pic14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic14MouseEntered
        Motor14.setBackground(Color.white);
    }//GEN-LAST:event_Pic14MouseEntered

    private void Pic14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic14MouseExited
        Motor14.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic14MouseExited

    private void Pic15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic15MouseClicked
        moreDetails(
                "/pictures/moto96.png",
                "Ducati Panigale V2",
                "A high-performance supersport motorcycle designed for both the track and street, featuring Ducati’s iconic styling, advanced electronics, and a powerful 955cc engine. The Panigale V2 offers a perfect balance between power, agility, and rider comfort, ideal for riders seeking thrilling performance.",
                "<b>Oil Change:</b> Every 7,500 km or 12 months\n"
                + "<b>Spark Plug Replacement:</b> Every 12,000 km\n"
                + "<b>Air Filter Cleaning/Replacement:</b> Every 12,000 km\n"
                + "<b>Brake Fluid Change:</b> Every 2 years\n"
                + "<b>Coolant Change:</b> Every 2 years",
                "<b>1.) Clutch Slippage:</b>\n"
                + "<b>Cause:</b> Aggressive track use or worn clutch plates due to heavy usage.\n"
                + "<b>Solution:</b> Inspect clutch fluid and adjust as needed. Replace the clutch plates if slippage occurs.\n"
                + "<b>2.) Chain Wear:</b>\n"
                + "<b>Cause:</b> High-performance engine and aggressive riding put strain on the chain.\n"
                + "<b>Solution:</b> Clean and lubricate the chain regularly, especially after track use. Check chain tension and replace it when necessary.\n"
                + "<b>3.) Overheating:</b>\n"
                + "<b>Cause:</b> Continuous high-speed riding or poor coolant circulation.\n"
                + "<b>Solution:</b> Ensure proper coolant levels and replace coolant every 2 years. Clean the radiator regularly to maintain airflow.", 
                "/pictures/part994.png",
                "/pictures/part995.png",
                "<b>Ducati Genuine 15W-50 Full Synthetic Oil</b>",
                "<b>NGK CR9EIX Iridium Spark Plug</b>",
                "₱3144",
                "₱465");
    }//GEN-LAST:event_Pic15MouseClicked

    private void Pic15MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic15MouseEntered
        Motor15.setBackground(Color.white);
    }//GEN-LAST:event_Pic15MouseEntered

    private void Pic15MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pic15MouseExited
        Motor15.setBackground(Color.decode("#000000"));
    }//GEN-LAST:event_Pic15MouseExited

    private void jScrollPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane2MouseClicked

    private void Cart1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Cart1MouseExited
        Cart1.setForeground(Color.white);
    }//GEN-LAST:event_Cart1MouseExited

    private void Cart1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Cart1MouseEntered
        Cart1.setForeground(Color.RED);
    }//GEN-LAST:event_Cart1MouseEntered

    private void Cart1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Cart1MouseClicked
        Cart.getInstance(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Cart1MouseClicked

    private void Parts1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Parts1MouseExited
        Parts1.setForeground(Color.WHITE);
    }//GEN-LAST:event_Parts1MouseExited

    private void Parts1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Parts1MouseEntered
        Parts1.setForeground(Color.RED);
    }//GEN-LAST:event_Parts1MouseEntered

    private void Parts1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Parts1MouseClicked
        new Parts(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Parts1MouseClicked

    private void Motorcycle1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motorcycle1MouseExited
        Motorcycle1.setForeground(Color.WHITE);
    }//GEN-LAST:event_Motorcycle1MouseExited

    private void Motorcycle1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motorcycle1MouseEntered
        Motorcycle1.setForeground(Color.RED);
    }//GEN-LAST:event_Motorcycle1MouseEntered

    private void Motorcycle1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Motorcycle1MouseClicked

    }//GEN-LAST:event_Motorcycle1MouseClicked

    private void home1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home1MouseExited
        home1.setForeground(Color.WHITE);
    }//GEN-LAST:event_home1MouseExited

    private void home1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home1MouseEntered
        home1.setForeground(Color.RED);
    }//GEN-LAST:event_home1MouseEntered

    private void home1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home1MouseClicked
        new Home(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_home1MouseClicked

    private void usernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseClicked
        new UserSpace(username.getText(), pass, mail).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_usernameMouseClicked

    private void usernameMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseEntered
        username.setForeground(Color.RED);
    }//GEN-LAST:event_usernameMouseEntered

    private void usernameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseExited
        username.setForeground(Color.white);
    }//GEN-LAST:event_usernameMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Motorcycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Motorcycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Motorcycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Motorcycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Motorcycle("Username","","").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Back1;
    private javax.swing.JLabel Back10;
    private javax.swing.JLabel Back11;
    private javax.swing.JLabel Back12;
    private javax.swing.JLabel Back13;
    private javax.swing.JLabel Back14;
    private javax.swing.JLabel Back15;
    private javax.swing.JLabel Back2;
    private javax.swing.JLabel Back3;
    private javax.swing.JLabel Back4;
    private javax.swing.JLabel Back5;
    private javax.swing.JLabel Back6;
    private javax.swing.JLabel Back7;
    private javax.swing.JLabel Back8;
    private javax.swing.JLabel Back9;
    private javax.swing.JLabel Cart1;
    private javax.swing.JPanel Motor1;
    private javax.swing.JPanel Motor10;
    private javax.swing.JPanel Motor11;
    private javax.swing.JPanel Motor12;
    private javax.swing.JPanel Motor13;
    private javax.swing.JPanel Motor14;
    private javax.swing.JPanel Motor15;
    private javax.swing.JPanel Motor2;
    private javax.swing.JPanel Motor3;
    private javax.swing.JPanel Motor4;
    private javax.swing.JPanel Motor5;
    private javax.swing.JPanel Motor6;
    private javax.swing.JPanel Motor7;
    private javax.swing.JPanel Motor8;
    private javax.swing.JPanel Motor9;
    private javax.swing.JLabel Motorcycle1;
    private javax.swing.JPanel NavBar2;
    private javax.swing.JLabel Parts1;
    private javax.swing.JLabel Pic1;
    private javax.swing.JLabel Pic10;
    private javax.swing.JLabel Pic11;
    private javax.swing.JLabel Pic12;
    private javax.swing.JLabel Pic13;
    private javax.swing.JLabel Pic14;
    private javax.swing.JLabel Pic15;
    private javax.swing.JLabel Pic2;
    private javax.swing.JLabel Pic3;
    private javax.swing.JLabel Pic4;
    private javax.swing.JLabel Pic5;
    private javax.swing.JLabel Pic6;
    private javax.swing.JLabel Pic7;
    private javax.swing.JLabel Pic8;
    private javax.swing.JLabel Pic9;
    private javax.swing.JLabel home1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
