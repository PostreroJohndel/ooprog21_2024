/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package newblottersystem;

/**
 *
 * @author mark arwin talaba
 */
public class NewblotterSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       lawgin lawginFrame = new lawgin();
       lawginFrame.setVisible(true);
       lawginFrame.pack();
       lawginFrame.setLocationRelativeTo(null);
    }
    
}
